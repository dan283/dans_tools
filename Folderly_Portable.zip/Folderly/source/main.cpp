#ifndef UNICODE
#define UNICODE
#endif
#define _UNICODE
#define NOMINMAX
#include <windows.h>
#include <windowsx.h>
#include <shobjidl.h>
#include <shellapi.h>
#include <gdiplus.h>
#include <dwmapi.h>
#include <thread>
#include <atomic>
#include <memory>
#include <fstream>
#include "organizer.hpp"
using namespace Gdiplus;
using org::wstring;
constexpr UINT DONE=WM_APP+1,PROGRESS=WM_APP+2;
HWND win,searchBox,folderEdit;WNDPROC oldEdit;float dpi=1;int W=1160,H=760;
std::vector<org::Entry> files;std::vector<int> visible;std::vector<org::Move> undo;
wstring root,query,status=L"Choose a folder to get started.",details;
bool keepYear=true,cleanTags=true,busy=false,cancelled=false;std::atomic<bool>cancelFlag{false};
int workKind=0;wstring scanOverride;
int editIndex=-1,scroll=0,previewScroll=0,hover=-1,hoverRow=-1,done=0,total=0;HFONT editFont;HBRUSH editBrush;std::thread worker;
Color bg(255,15,19,27),panel(255,23,29,40),line(255,43,53,69),ink(255,232,239,249),muted(255,145,161,183),accent(255,100,176,255),green(255,113,224,176),red(255,255,148,139);
struct Button{RectF r;int id;wstring label;bool enabled,primary;};std::vector<Button> buttons;
int px(float v){return int(v*dpi+0.5f);}float leftWidth(){return W-362;}float listTop(){return 264;}float listHeight(){return H-338;}
void repaint(){InvalidateRect(win,nullptr,FALSE);}
void text(Graphics&g,const wstring&s,float x,float y,float w,float h,float sz=13,Color col=ink,bool bold=false,int align=0){FontFamily f(L"Segoe UI");Font ft(&f,sz,bold?FontStyleBold:FontStyleRegular,UnitPixel);SolidBrush b(col);StringFormat sf;sf.SetTrimming(StringTrimmingEllipsisCharacter);sf.SetFormatFlags(StringFormatFlagsNoWrap);sf.SetLineAlignment(StringAlignmentCenter);if(align)sf.SetAlignment(StringAlignmentCenter);g.DrawString(s.c_str(),-1,&ft,RectF(x,y,w,h),&sf,&b);}
void box(Graphics&g,RectF r,Color fill,float radius=10,Color border=Color(0,0,0,0)){
 GraphicsPath p;float d=radius*2;p.AddArc(r.X,r.Y,d,d,180,90);p.AddArc(r.GetRight()-d,r.Y,d,d,270,90);p.AddArc(r.GetRight()-d,r.GetBottom()-d,d,d,0,90);p.AddArc(r.X,r.GetBottom()-d,d,d,90,90);p.CloseFigure();SolidBrush b(fill);g.FillPath(&b,&p);if(border.GetA()){Pen pen(border);g.DrawPath(&pen,&p);}
}
void rule(Graphics&g,float x,float y,float w){Pen p(line);g.DrawLine(&p,x,y,x+w,y);}
void folderIcon(Graphics&g,float x,float y,float size,Color c){Pen p(c,1.7);g.DrawLine(&p,x,y+size*.25f,x+size*.37f,y+size*.25f);g.DrawLine(&p,x+size*.37f,y+size*.25f,x+size*.5f,y+size*.4f);g.DrawLine(&p,x+size*.5f,y+size*.4f,x+size,y+size*.4f);g.DrawLine(&p,x+size,y+size*.4f,x+size,y+size);g.DrawLine(&p,x+size,y+size,x,y+size);g.DrawLine(&p,x,y+size,x,y+size*.25f);}
void checkbox(Graphics&g,float x,float y,bool checked){box(g,RectF(x,y,18,18),checked?accent:panel,4,checked?accent:line);if(checked){Pen p(bg,2);g.DrawLine(&p,x+4,y+9,x+8,y+13);g.DrawLine(&p,x+8,y+13,x+14,y+5);}}
void button(Graphics&g,int id,RectF r,const wstring&label,bool enabled=true,bool primary=false){buttons.push_back({r,id,label,enabled,primary});Color c=primary?accent:Color(255,31,40,55);if(!enabled)c=Color(255,29,36,47);else if(hover==id)c=primary?Color(255,137,196,255):Color(255,43,56,75);box(g,r,c,8,primary?Color(0,0,0,0):line);text(g,label,r.X+8,r.Y,r.Width-16,r.Height,13,enabled?(primary?bg:ink):muted,true,1);}
wstring sizeText(unsigned long long n){const wchar_t*u[]={L"B",L"KB",L"MB",L"GB",L"TB"};int i=0;double v=n;while(v>=1024&&i<4){v/=1024;++i;}wchar_t b[80];swprintf(b,80,i?L"%.1f %ls":L"%.0f %ls",v,u[i]);return b;}
void layout(){if(!win)return;MoveWindow(searchBox,px(42),px(194),px(leftWidth()-62),px(27),TRUE);if(editIndex>=0){auto it=std::find(visible.begin(),visible.end(),editIndex);if(it!=visible.end()){int n=int(it-visible.begin());float y=listTop()+n*78-scroll+37;MoveWindow(folderEdit,px(82),px(y),px(leftWidth()-136),px(27),TRUE);}}}
void rebuild(){visible.clear();auto q=org::lower(query);for(int i=0;i<(int)files.size();++i)if(q.empty()||org::lower(files[i].name+L" "+files[i].folder).find(q)!=wstring::npos)visible.push_back(i);scroll=std::max(0,std::min(scroll,std::max(0,int(visible.size()*78-listHeight()))));layout();repaint();}
void validate(){for(auto&e:files)e.error=org::validate(root,e);}
void finishEdit(bool save=true){if(editIndex<0)return;if(save){int n=GetWindowTextLengthW(folderEdit);wstring s(n+1,L'\0');GetWindowTextW(folderEdit,&s[0],n+1);s.resize(n);files[editIndex].folder=org::trim(s);files[editIndex].error=org::validate(root,files[editIndex]);}editIndex=-1;ShowWindow(folderEdit,SW_HIDE);SetFocus(win);rebuild();}
void beginEdit(int i){finishEdit();editIndex=i;SetWindowTextW(folderEdit,files[i].folder.c_str());layout();ShowWindow(folderEdit,SW_SHOW);SetFocus(folderEdit);SendMessageW(folderEdit,EM_SETSEL,0,-1);}
void paint(Graphics&g){g.SetSmoothingMode(SmoothingModeAntiAlias);g.SetTextRenderingHint(TextRenderingHintClearTypeGridFit);g.Clear(bg);buttons.clear();
 box(g,RectF(28,25,43,43),Color(255,28,53,74),12);folderIcon(g,39,33,21,accent);
 text(g,L"Folderly",84,24,250,28,25,ink,true);text(g,L"A little order. A lot less clicking.",85,54,390,22,12,muted);
 box(g,RectF(W-170,32,142,27),Color(255,25,44,39),13);text(g,L"PORTABLE  /  OFFLINE",W-166,32,134,27,10,green,true,1);
 box(g,RectF(28,92,W-56,66),panel,12,line);folderIcon(g,46,111,20,muted);text(g,root.empty()?L"No folder selected":root,80,103,W-286,22,14,ink,true);text(g,L"Only loose files in this folder. Existing subfolders stay as they are.",80,125,W-300,20,11,muted);button(g,1,RectF(W-200,105,154,39),L"Choose folder",!busy,true);
 float L=leftWidth();
 box(g,RectF(28,186,L-48,42),panel,9,line);
 int selected=0,conflicts=0;unsigned long long bytes=0;std::map<wstring,std::vector<const org::Entry*>>groups;for(auto&e:files)if(e.selected){++selected;bytes+=e.size;if(!e.error.empty())++conflicts;groups[e.folder].push_back(&e);}
 text(g,L"FILES  "+std::to_wstring(visible.size())+L" / "+std::to_wstring(files.size()),30,233,220,24,10,muted,true);
 button(g,2,RectF(L-211,235,59,22),L"All",!busy&&!files.empty());button(g,3,RectF(L-145,235,59,22),L"None",!busy&&!files.empty());button(g,4,RectF(L-79,235,59,22),L"Rescan",!busy&&!root.empty());
 if(files.empty()){
  folderIcon(g,L/2-24,330,48,Color(255,67,91,118));text(g,root.empty()?L"Turn loose files into tidy folders":L"This folder is already tidy",44,404,L-76,30,19,ink,true,1);
  text(g,root.empty()?L"Choose a folder. Review names. Organize in one click.":L"No loose files to organize. Choose another folder.",44,444,L-76,26,12,muted,false,1);
 }else if(visible.empty()){text(g,L"No matching files",44,350,L-76,30,17,muted,false,1);}
 else{
  GraphicsState save=g.Save();g.SetClip(RectF(28,listTop(),L-48,listHeight()));
  int first=scroll/78,last=std::min((int)visible.size(),first+int(listHeight()/78)+2);
  for(int n=first;n<last;++n){int i=visible[n];auto&e=files[i];float y=listTop()+n*78-scroll;Color fill=i==hoverRow?Color(255,28,37,51):panel;box(g,RectF(28,y,L-48,71),fill,9,i==editIndex?accent:line);checkbox(g,42,y+25,e.selected);
   text(g,e.name,78,y+6,L-230,27,13,e.selected?ink:muted,true);text(g,sizeText(e.size),L-137,y+7,92,24,11,muted,false,1);
   text(g,L"↳",79,y+35,21,25,16,muted);folderIcon(g,104,y+41,12,e.error.empty()?green:red);
   text(g,e.folder+L" /",127,y+34,L-224,27,12,e.error.empty()?green:red);text(g,L"EDIT",L-76,y+34,39,25,9,muted,true);
   if(!e.error.empty())text(g,L"!",L-173,y+7,24,24,15,red,true,1);
  }
  g.Restore(save);
  float full=visible.size()*78;if(full>listHeight()){float sh=std::max(22.f,listHeight()*listHeight()/full),sy=listTop()+scroll/(full-listHeight())*(listHeight()-sh);box(g,RectF(L-15,sy,4,sh),Color(255,72,88,112),2);}
 }
 // Preview sidebar.
 box(g,RectF(L+4,186,330,H-260),panel,12,line);text(g,L"YOUR PREVIEW",L+24,201,275,24,11,muted,true);
 text(g,std::to_wstring(selected),L+24,233,130,42,34,ink,true);text(g,L"files selected",L+24,275,130,25,12,muted);text(g,std::to_wstring(groups.size()),L+183,233,124,42,34,green,true);text(g,L"destination folders",L+183,275,130,25,12,muted);
 rule(g,L+24,310,290);
 checkbox(g,L+24,329,keepYear);text(g,L"Keep the year in movie titles",L+51,324,266,28,12,ink);buttons.push_back({RectF(L+20,321,292,33),5,L"",!busy,false});
 checkbox(g,L+24,365,cleanTags);text(g,L"Clean resolution & release tags",L+51,360,266,28,12,ink);buttons.push_back({RectF(L+20,357,292,33),6,L"",!busy,false});
 text(g,L"Click a green folder name to edit it.",L+24,395,285,25,11,muted);
 rule(g,L+24,428,290);text(g,L"DESTINATION FOLDERS",L+24,439,286,23,10,muted,true);
 float py=470-previewScroll,ph=H-578;int groupHeight=0;auto save=g.Save();g.SetClip(RectF(L+20,470,294,std::max(0.f,ph)));
 if(groups.empty())text(g,L"Select files to see the plan.",L+24,470,286,27,12,muted);
 for(auto&kv:groups){folderIcon(g,L+26,py+5,14,accent);text(g,kv.first,L+50,py,250,25,12,ink,true);text(g,std::to_wstring(kv.second.size())+L" file"+(kv.second.size()==1?L"":L"s"),L+50,py+23,220,22,11,muted);py+=55;groupHeight+=55;}
 g.Restore(save);previewScroll=std::max(0,std::min(previewScroll,std::max(0,groupHeight-int(ph))));
 text(g,conflicts?std::to_wstring(conflicts)+L" selected file(s) have conflicts":L"No overwrites. Filenames stay unchanged.",L+24,H-102,286,22,11,conflicts?red:green);
 // Fixed footer.
 rule(g,28,H-65,W-56);text(g,busy?L"Working… "+std::to_wstring(done)+L" / "+std::to_wstring(total):status,28,H-56,W-418,25,12,muted);
 text(g,busy?L"Cancel stops after the current file.":L"Selected: "+sizeText(bytes)+L"  ·  Double-click a row to edit its folder",28,H-33,W-418,21,10,muted);
 button(g,7,RectF(W-370,H-53,138,38),busy?L"Cancel":L"Undo last batch",busy||!undo.empty());button(g,8,RectF(W-219,H-53,191,38),busy?(workKind==0?L"Scanning…":workKind==2?L"Restoring…":L"Organizing…"):L"Organize "+std::to_wstring(selected)+L" files",!busy&&selected>0,true);
}
struct Result{std::vector<org::Entry> entries;std::vector<org::Move> moved;wstring message,detail;int kind=0;};
void startScan(){if(busy)return;finishEdit();if(worker.joinable()){worker.join();}busy=true;workKind=0;done=0;total=0;cancelFlag=false;status=L"Scanning…";EnableWindow(searchBox,FALSE);repaint();auto path=root;bool year=keepYear,clean=cleanTags;
 worker=std::thread([path,year,clean]{auto r=new Result;r->kind=0;try{r->entries=org::scan(path);org::suggest(r->entries,year,clean);for(auto&e:r->entries)e.error=org::validate(path,e);r->message=L"Scanned "+std::to_wstring(r->entries.size())+L" loose files. Review the preview before organizing.";}catch(std::exception&e){std::string s=e.what();r->message=wstring(s.begin(),s.end());}PostMessageW(win,DONE,0,(LPARAM)r);});
}
void chooseFolder(){finishEdit();IFileOpenDialog*d=nullptr;if(SUCCEEDED(CoCreateInstance(CLSID_FileOpenDialog,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&d)))){DWORD flags;d->GetOptions(&flags);d->SetOptions(flags|FOS_PICKFOLDERS|FOS_FORCEFILESYSTEM|FOS_PATHMUSTEXIST);d->SetTitle(L"Choose the folder containing your loose files");if(!root.empty()){IShellItem*item=nullptr;if(SUCCEEDED(SHCreateItemFromParsingName(root.c_str(),nullptr,IID_PPV_ARGS(&item)))){d->SetFolder(item);item->Release();}}if(SUCCEEDED(d->Show(win))){IShellItem*i=nullptr;if(SUCCEEDED(d->GetResult(&i))){PWSTR p=nullptr;if(SUCCEEDED(i->GetDisplayName(SIGDN_FILESYSPATH,&p))){root=p;CoTaskMemFree(p);query.clear();SetWindowTextW(searchBox,L"");scroll=previewScroll=0;startScan();}i->Release();}}d->Release();}}
void runMoves(){finishEdit();int n=0,conflicts=0;for(auto&e:files)if(e.selected){++n;if(!org::validate(root,e).empty())++conflicts;}if(!n)return;
 wstring msg=L"Create destination folders and move "+std::to_wstring(n)+L" selected files inside:\n\n"+root+L"\n\nExisting destination files will never be replaced.";if(conflicts)msg+=L"\n\n"+std::to_wstring(conflicts)+L" file(s) have conflicts and will be skipped.";if(!undo.empty())msg+=L"\n\nUndo will apply to this new batch only.";
 if(MessageBoxW(win,msg.c_str(),L"Review complete — organize files?",MB_OKCANCEL|MB_ICONQUESTION)!=IDOK)return;
 if(worker.joinable()){worker.join();}auto copy=files;auto path=root;busy=true;workKind=1;done=0;total=n;cancelFlag=false;EnableWindow(searchBox,FALSE);repaint();
 worker=std::thread([copy,path]()mutable{auto r=new Result;r->kind=1;int skipped=0,processed=0;
  for(auto&e:copy)if(e.selected){if(cancelFlag.load())break;org::Move m;if(org::moveOne(path,e,m)){r->moved.push_back(m);e.selected=false;e.error=L"Moved";}else{++skipped;r->detail+=e.name+L"\n  "+e.error+L"\n\n";}PostMessageW(win,PROGRESS,++processed,0);}
  r->message=L"Moved "+std::to_wstring(r->moved.size())+L" files"+(skipped?L" · "+std::to_wstring(skipped)+L" skipped":L"")+(cancelFlag.load()?L" · Cancelled":L"");
  // Remove moved files from current preview, preserve failed and unselected edits.
  copy.erase(std::remove_if(copy.begin(),copy.end(),[](auto&e){return e.error==L"Moved";}),copy.end());r->entries=std::move(copy);PostMessageW(win,DONE,0,(LPARAM)r);
 });
}
void runUndo(){if(undo.empty())return;if(MessageBoxW(win,(L"Return "+std::to_wstring(undo.size())+L" files from the last batch to their original locations?\n\nChanged files and conflicting destinations will be skipped. Created folders are kept.").c_str(),L"Undo last batch",MB_OKCANCEL|MB_ICONQUESTION)!=IDOK)return;
 if(worker.joinable()){worker.join();}busy=true;workKind=2;done=0;total=undo.size();cancelFlag=false;EnableWindow(searchBox,FALSE);repaint();auto batch=undo;
 worker=std::thread([batch]{auto r=new Result;r->kind=2;int restored=0,k=0;for(auto it=batch.rbegin();it!=batch.rend();++it){if(cancelFlag.load()){r->moved.insert(r->moved.end(),it,batch.rend());break;}wstring why;if(org::undoOne(*it,why))++restored;else{r->moved.push_back(*it);r->detail+=it->dest+L"\n  "+why+L"\n\n";}PostMessageW(win,PROGRESS,++k,0);}r->message=L"Restored "+std::to_wstring(restored)+L" files"+(r->moved.empty()?L"":L" · Some files remain in their folders");PostMessageW(win,DONE,0,(LPARAM)r);});
}
void action(int id){if(busy){if(id==7)cancelFlag=true;return;}finishEdit();switch(id){case 1:chooseFolder();break;case 2:for(int i:visible)files[i].selected=true;repaint();break;case 3:for(int i:visible)files[i].selected=false;repaint();break;case 4:startScan();break;case 5:case 6:{if(MessageBoxW(win,L"Regenerate suggested folder names? This replaces any folder names you edited in the current preview.",L"Update suggestions",MB_OKCANCEL|MB_ICONQUESTION)!=IDOK)break;if(id==5)keepYear=!keepYear;else cleanTags=!cleanTags;org::suggest(files,keepYear,cleanTags);validate();rebuild();break;}case 7:runUndo();break;case 8:runMoves();break;}}
LRESULT CALLBACK EditProc(HWND h,UINT m,WPARAM w,LPARAM l){if(m==WM_KEYDOWN&&(w==VK_RETURN||w==VK_ESCAPE)){finishEdit(w==VK_RETURN);return 0;}return CallWindowProcW(oldEdit,h,m,w,l);}
LRESULT CALLBACK Proc(HWND h,UINT m,WPARAM w,LPARAM l){switch(m){
 case WM_CREATE:{win=h;editFont=CreateFontW(-px(13),0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");editBrush=CreateSolidBrush(RGB(23,29,40));searchBox=CreateWindowExW(0,L"EDIT",L"",WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL,0,0,10,10,h,(HMENU)100,nullptr,nullptr);SendMessageW(searchBox,WM_SETFONT,(WPARAM)editFont,0);SendMessageW(searchBox,EM_SETCUEBANNER,TRUE,(LPARAM)L"Search files or destination folders");folderEdit=CreateWindowExW(0,L"EDIT",L"",WS_CHILD|ES_AUTOHSCROLL,0,0,10,10,h,(HMENU)101,nullptr,nullptr);SendMessageW(folderEdit,WM_SETFONT,(WPARAM)editFont,0);SendMessageW(folderEdit,EM_SETLIMITTEXT,200,0);oldEdit=(WNDPROC)SetWindowLongPtrW(folderEdit,GWLP_WNDPROC,(LONG_PTR)EditProc);DragAcceptFiles(h,TRUE);BOOL dark=TRUE;DwmSetWindowAttribute(h,20,&dark,sizeof(dark));return 0;}
 case WM_SIZE:W=int(LOWORD(l)/dpi);H=int(HIWORD(l)/dpi);layout();rebuild();return 0;
 case WM_GETMINMAXINFO:((MINMAXINFO*)l)->ptMinTrackSize={px(1020),px(700)};return 0;
 case WM_ERASEBKGND:return 1;
 case WM_PAINT:{PAINTSTRUCT ps;HDC dc=BeginPaint(h,&ps);RECT rc;GetClientRect(h,&rc);HDC mem=CreateCompatibleDC(dc);HBITMAP bmp=CreateCompatibleBitmap(dc,rc.right,rc.bottom);auto old=SelectObject(mem,bmp);{Graphics g(mem);g.ScaleTransform(dpi,dpi);paint(g);}BitBlt(dc,0,0,rc.right,rc.bottom,mem,0,0,SRCCOPY);SelectObject(mem,old);DeleteObject(bmp);DeleteDC(mem);EndPaint(h,&ps);return 0;}
 case WM_CTLCOLOREDIT:SetTextColor((HDC)w,RGB(232,239,249));SetBkColor((HDC)w,RGB(23,29,40));return (LRESULT)editBrush;
 case WM_COMMAND:if(LOWORD(w)==100&&HIWORD(w)==EN_CHANGE){int n=GetWindowTextLengthW(searchBox);query.assign(n+1,L'\0');GetWindowTextW(searchBox,&query[0],n+1);query.resize(n);scroll=0;rebuild();}return 0;
 case WM_LBUTTONDOWN:case WM_LBUTTONDBLCLK:{SetFocus(h);float x=GET_X_LPARAM(l)/dpi,y=GET_Y_LPARAM(l)/dpi;for(auto&b:buttons)if(b.r.Contains(x,y)){if(b.enabled)action(b.id);return 0;}if(busy)return 0;if(x>=28&&x<leftWidth()-20&&y>=listTop()&&y<listTop()+listHeight()){int n=int((y-listTop()+scroll)/78);if(n>=0&&n<(int)visible.size()){int i=visible[n];float ry=listTop()+n*78-scroll;if(x<72){finishEdit();files[i].selected=!files[i].selected;repaint();}else if(y>ry+32||m==WM_LBUTTONDBLCLK)beginEdit(i);else if(!files[i].error.empty())MessageBoxW(h,files[i].error.c_str(),files[i].name.c_str(),MB_OK|MB_ICONINFORMATION);}return 0;}finishEdit();return 0;}
 case WM_MOUSEMOVE:{float x=GET_X_LPARAM(l)/dpi,y=GET_Y_LPARAM(l)/dpi;int hit=-1,row=-1;for(auto&b:buttons)if(b.r.Contains(x,y)&&b.enabled)hit=b.id;if(x>=28&&x<leftWidth()-20&&y>=listTop()&&y<listTop()+listHeight()){int n=int((y-listTop()+scroll)/78);if(n>=0&&n<(int)visible.size())row=visible[n];}if(hit!=hover||row!=hoverRow){hover=hit;hoverRow=row;repaint();}SetCursor(LoadCursorW(nullptr,hit>=0?IDC_HAND:IDC_ARROW));return 0;}
 case WM_MOUSEWHEEL:{if(editIndex>=0)finishEdit();POINT p{GET_X_LPARAM(l),GET_Y_LPARAM(l)};ScreenToClient(h,&p);int delta=GET_WHEEL_DELTA_WPARAM(w)/WHEEL_DELTA*78;if(p.x/dpi>leftWidth()){previewScroll=std::max(0,previewScroll-delta);repaint();}else{scroll=std::max(0,scroll-delta);rebuild();}return 0;}
 case WM_KEYDOWN:if(w==VK_F5&&!busy&&!root.empty())startScan();if(w==VK_ESCAPE&&busy)cancelFlag=true;if(w=='O'&&(GetKeyState(VK_CONTROL)&0x8000)&&!busy)chooseFolder();if(w=='Z'&&(GetKeyState(VK_CONTROL)&0x8000)&&!busy)runUndo();if(w=='A'&&(GetKeyState(VK_CONTROL)&0x8000)&&!busy){for(auto&e:files)e.selected=true;repaint();}return 0;
 case WM_DROPFILES:{HDROP drop=(HDROP)w;if(!busy){wchar_t path[32768];DragQueryFileW(drop,0,path,32768);if(GetFileAttributesW(path)&FILE_ATTRIBUTE_DIRECTORY){root=path;scroll=previewScroll=0;query.clear();SetWindowTextW(searchBox,L"");startScan();}else MessageBoxW(h,L"Drop a folder containing the files you want to organize.",L"Choose a folder",MB_OK);}DragFinish(drop);return 0;}
 case PROGRESS:done=(int)w;repaint();return 0;
 case DONE:{if(worker.joinable()){worker.join();}std::unique_ptr<Result>r((Result*)l);busy=false;EnableWindow(searchBox,TRUE);status=r->message;details=r->detail;if(r->kind==0){files=std::move(r->entries);if(!scanOverride.empty()){status=scanOverride;scanOverride.clear();}}if(r->kind==1){files=std::move(r->entries);if(!r->moved.empty())undo=std::move(r->moved);}if(r->kind==2){undo=std::move(r->moved);scanOverride=status;startScan();}scroll=0;rebuild();if(!details.empty())MessageBoxW(h,(status+L"\n\n"+details.substr(0,12000)).c_str(),L"Operation results",MB_OK|MB_ICONINFORMATION);return 0;}
 case WM_CLOSE:if(busy){MessageBoxW(h,L"Please let the current operation finish, or press Cancel first.",L"Operation in progress",MB_OK);return 0;}finishEdit();DestroyWindow(h);return 0;
 case WM_DESTROY:if(worker.joinable()){worker.join();}DeleteObject(editFont);DeleteObject(editBrush);PostQuitMessage(0);return 0;
 }return DefWindowProcW(h,m,w,l);}
int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,PWSTR,int show){
 CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED);SetProcessDPIAware();HDC dc=GetDC(nullptr);dpi=GetDeviceCaps(dc,LOGPIXELSX)/96.f;ReleaseDC(nullptr,dc);ULONG_PTR token;GdiplusStartupInput input;GdiplusStartup(&token,&input,nullptr);
 WNDCLASSEXW wc{};wc.cbSize=sizeof(wc);wc.style=CS_DBLCLKS;wc.lpfnWndProc=Proc;wc.hInstance=instance;wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);wc.hIcon=LoadIconW(instance,MAKEINTRESOURCEW(1));wc.hIconSm=wc.hIcon;wc.lpszClassName=L"FolderlyPortable";RegisterClassExW(&wc);
 RECT r{0,0,px(W),px(H)};AdjustWindowRectEx(&r,WS_OVERLAPPEDWINDOW,FALSE,0);win=CreateWindowExW(0,wc.lpszClassName,L"Folderly — Portable File Organizer",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,r.right-r.left,r.bottom-r.top,nullptr,nullptr,instance,nullptr);ShowWindow(win,show);UpdateWindow(win);
 int argc;auto argv=CommandLineToArgvW(GetCommandLineW(),&argc);if(argc>1){root=argv[1];startScan();}LocalFree(argv);
 MSG msg;while(GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}GdiplusShutdown(token);CoUninitialize();return 0;
}
