#pragma once
#include <windows.h>
#include <string>
#include <vector>
#include <regex>
#include <algorithm>
#include <map>
#include <set>
#include <cwctype>
namespace org {
using std::wstring;
struct Entry { wstring name,folder,error; unsigned long long size=0; FILETIME stamp{}; bool selected=true; };
struct Move { wstring source,dest; unsigned long long size; FILETIME stamp; };
inline wstring lower(wstring s){std::transform(s.begin(),s.end(),s.begin(),towlower);return s;}
inline wstring trim(wstring s){auto ws=[](wchar_t c){return iswspace(c)!=0;};while(!s.empty()&&ws(s.front()))s.erase(s.begin());while(!s.empty()&&ws(s.back()))s.pop_back();return s;}
inline wstring join(const wstring&a,const wstring&b){return a+((a.empty()||a.back()==L'\\')?L"":L"\\")+b;}
inline wstring xp(const wstring&p){if(p.rfind(L"\\\\?\\",0)==0)return p;if(p.rfind(L"\\\\",0)==0)return L"\\\\?\\UNC\\"+p.substr(2);return L"\\\\?\\"+p;}
inline wstring error(DWORD n=GetLastError()){wchar_t* p=nullptr;FormatMessageW(FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM|FORMAT_MESSAGE_IGNORE_INSERTS,nullptr,n,0,(LPWSTR)&p,0,nullptr);wstring s=p?trim(p):L"Windows error "+std::to_wstring(n);if(p)LocalFree(p);return s;}
inline wstring ext(const wstring&s){auto p=s.find_last_of(L'.');return p==wstring::npos?L"":lower(s.substr(p+1));}
inline wstring stem(const wstring&s){auto p=s.find_last_of(L'.');return p==wstring::npos||p==0?s:s.substr(0,p);}
inline wstring invalid(const wstring&s){if(s.empty()||s==L"."||s==L"..")return L"Enter a folder name";if(s.size()>200)return L"Folder name is too long";if(s.back()==L'.'||s.back()==L' ')return L"Remove the trailing dot or space";for(auto c:s)if(c<32||wstring(L"\\/:*?\"<>|").find(c)!=wstring::npos)return L"Invalid folder character";static const std::wregex reserved(LR"(^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?$)",std::regex::icase);if(std::regex_match(s,reserved))return L"Reserved Windows folder name";return L"";}
inline wstring safe(wstring s){for(auto &c:s)if(c<32||wstring(L"\\/:*?\"<>|").find(c)!=wstring::npos)c=L' ';s=trim(s);while(!s.empty()&&(s.back()==L'.'||s.back()==L' '))s.pop_back();if(s.empty())s=L"Untitled";if(!invalid(s).empty())s=L"_"+s;if(s.size()>190)s.resize(190);return s;}
inline wstring title(const wstring&filename,bool keepYear=true,bool clean=true){
 wstring s=stem(filename);if(!clean)return safe(s);
 std::replace(s.begin(),s.end(),L'.',L' ');std::replace(s.begin(),s.end(),L'_',L' ');
 static const std::wregex tags(LR"(\b(2160p|1080[pi]|720p|480p|576p|4k|uhd|blu[ -]?ray|bdremux|bdrip|brrip|web[ -]?dl|webrip|webdl|dvdrip|hdrip|hdtv|x26[45]|h[ -]?26[45]|hevc|av1|remux|aac[0-9]*|dts|truehd|atmos|proper|repack)\b)",std::regex::icase);
 static const std::wregex brackets(LR"([\[\](){}])"),spaces(LR"(\s+)");
 std::wsmatch m;if(std::regex_search(s,m,tags))s=s.substr(0,m.position());
 static const std::wregex year(LR"(\b((?:19|20)[0-9]{2})\b)");
 // Use the last plausible release year, never a leading numeric title such as 1917.
 static const std::wregex yearTail(LR"(^[\s\[\](){}-]*(?:(?:eng|english|hun|hungarian|deu|ger|german|forced|sdh|poster|cover|fanart|extended|unrated|remastered|directors|director|cut)[\s\[\](){}-]*)*$)",std::regex::icase);
 std::wsregex_iterator it(s.begin(),s.end(),year),end;size_t pos=wstring::npos;wstring y;
 SYSTEMTIME now{};GetLocalTime(&now);
 for(;it!=end;++it){auto match=*it;auto at=(size_t)match.position();int n=std::stoi(match[1].str());if(at>0&&n<=now.wYear+1&&std::regex_match(s.substr(at+match.length()),yearTail)){pos=at;y=match[1];}}
 if(pos!=wstring::npos){s=s.substr(0,pos);s=trim(std::regex_replace(s,brackets,L" "));if(keepYear)s+=L" ("+y+L")";}
 else s=std::regex_replace(s,brackets,L" ");
 s=trim(std::regex_replace(s,spaces,L" "));while(!s.empty()&&(s.back()==L'-'||s.back()==L' '))s.pop_back();return safe(s.empty()?stem(filename):s);
}
inline bool video(const wstring&s){static const std::set<wstring> v={L"mkv",L"mp4",L"avi",L"mov",L"wmv",L"m4v",L"webm",L"mpg",L"mpeg",L"ts"};return v.count(ext(s));}
inline void suggest(std::vector<Entry>&files,bool year,bool clean){
 for(auto&e:files)e.folder=title(e.name,year,clean);
 if(!clean)return;
 static const std::set<wstring> companions={L"srt",L"sub",L"idx",L"ass",L"ssa",L"vtt",L"nfo",L"jpg",L"jpeg",L"png",L"webp"};
 static const std::wregex suffix(LR"((?:[ ._-]+(?:eng|en|english|hun|hu|hungarian|deu|de|ger|german|forced|sdh|poster|cover|fanart))+$)",std::regex::icase);
 for(auto&e:files)if(companions.count(ext(e.name))){
  auto raw=lower(std::regex_replace(stem(e.name),suffix,L""));std::vector<const Entry*>matches;
  for(auto&v:files)if(video(v.name)){
   auto base=lower(stem(v.name));bool exact=raw==base;
   bool normalized=lower(title(raw,year,true))==lower(v.folder);
   if(exact||normalized)matches.push_back(&v);
  }
  if(matches.size()==1)e.folder=matches[0]->folder;
 }
}
inline DWORD attrs(const wstring&p){return GetFileAttributesW(xp(p).c_str());}
inline bool metadata(const wstring&p,unsigned long long&sz,FILETIME&t){WIN32_FILE_ATTRIBUTE_DATA d{};if(!GetFileAttributesExW(xp(p).c_str(),GetFileExInfoStandard,&d))return false;if(d.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT)){SetLastError(ERROR_ACCESS_DENIED);return false;}sz=((unsigned long long)d.nFileSizeHigh<<32)|d.nFileSizeLow;t=d.ftLastWriteTime;return true;}
inline std::vector<Entry> scan(const wstring&root){
 DWORD ra=attrs(root);if(ra==INVALID_FILE_ATTRIBUTES)throw std::runtime_error("Folder unavailable");if(!(ra&FILE_ATTRIBUTE_DIRECTORY)||(ra&FILE_ATTRIBUTE_REPARSE_POINT))throw std::runtime_error("Choose a real folder, not a linked folder");
 WIN32_FIND_DATAW d{};HANDLE h=FindFirstFileW(xp(join(root,L"*")).c_str(),&d);std::vector<Entry> out;
 if(h==INVALID_HANDLE_VALUE){if(GetLastError()==ERROR_FILE_NOT_FOUND)return out;throw std::runtime_error("Unable to read this folder");}
 wchar_t me[32768];GetModuleFileNameW(nullptr,me,32768);
 do{if(d.dwFileAttributes&(FILE_ATTRIBUTE_DIRECTORY|FILE_ATTRIBUTE_REPARSE_POINT))continue;if(lower(join(root,d.cFileName))==lower(me))continue;Entry e;e.name=d.cFileName;e.size=((unsigned long long)d.nFileSizeHigh<<32)|d.nFileSizeLow;e.stamp=d.ftLastWriteTime;out.push_back(e);}while(FindNextFileW(h,&d));DWORD end=GetLastError();FindClose(h);if(end!=ERROR_NO_MORE_FILES)throw std::runtime_error("Folder enumeration failed");
 std::sort(out.begin(),out.end(),[](auto&a,auto&b){return lower(a.name)<lower(b.name);});return out;
}
inline wstring validate(const wstring&root,const Entry&e){
 DWORD ra=attrs(root);if(ra==INVALID_FILE_ATTRIBUTES||!(ra&FILE_ATTRIBUTE_DIRECTORY)||(ra&FILE_ATTRIBUTE_REPARSE_POINT))return L"Source folder unavailable or linked; rescan";
 auto why=invalid(e.folder);if(!why.empty())return why;
 auto dir=join(root,e.folder);DWORD da=attrs(dir);
 if(da!=INVALID_FILE_ATTRIBUTES){if(!(da&FILE_ATTRIBUTE_DIRECTORY))return L"A file already uses this folder name";if(da&FILE_ATTRIBUTE_REPARSE_POINT)return L"Linked destination folders are skipped";}
 else if(GetLastError()!=ERROR_FILE_NOT_FOUND&&GetLastError()!=ERROR_PATH_NOT_FOUND)return L"Cannot access destination";
 if(attrs(join(dir,e.name))!=INVALID_FILE_ATTRIBUTES)return L"Destination already exists; will skip";
 DWORD de=GetLastError();if(de!=ERROR_FILE_NOT_FOUND&&de!=ERROR_PATH_NOT_FOUND)return L"Cannot access destination file";
 return L"";
}
inline bool moveOne(const wstring&root,Entry&e,Move&rec){
 e.error=validate(root,e);if(!e.error.empty())return false;
 auto src=join(root,e.name),dir=join(root,e.folder),dst=join(dir,e.name);
 unsigned long long sz;FILETIME ft;if(!metadata(src,sz,ft)){e.error=L"Source unavailable: "+error();return false;}
 if(sz!=e.size||CompareFileTime(&ft,&e.stamp)!=0){e.error=L"Source changed since preview; rescan";return false;}
 bool created=CreateDirectoryW(xp(dir).c_str(),nullptr)!=0;
 if(!created&&GetLastError()!=ERROR_ALREADY_EXISTS){e.error=error();return false;}
 // Revalidate after creation, including reparse point checks. Never replace or copy.
 e.error=validate(root,e);if(!e.error.empty()){if(created)RemoveDirectoryW(xp(dir).c_str());return false;}
 if(!MoveFileExW(xp(src).c_str(),xp(dst).c_str(),MOVEFILE_WRITE_THROUGH)){e.error=error();if(created)RemoveDirectoryW(xp(dir).c_str());return false;}
 rec={src,dst,e.size,e.stamp};return true;
}
inline bool undoOne(const Move&m,wstring&why){
 if(attrs(m.source)!=INVALID_FILE_ATTRIBUTES){why=L"Original location already contains a file";return false;}
 unsigned long long sz;FILETIME ft;if(!metadata(m.dest,sz,ft)){why=L"Moved file unavailable";return false;}if(sz!=m.size||CompareFileTime(&ft,&m.stamp)!=0){why=L"Moved file changed; skipped";return false;}
 auto parent=m.dest.substr(0,m.dest.find_last_of(L'\\'));if(attrs(parent)&FILE_ATTRIBUTE_REPARSE_POINT){why=L"Linked folder; skipped";return false;}
 if(!MoveFileExW(xp(m.dest).c_str(),xp(m.source).c_str(),MOVEFILE_WRITE_THROUGH)){why=error();return false;}return true;
}
}
