FOLDERLY — PORTABLE FILE ORGANIZER
Windows 10 / 11, 64-bit. Native C++. No installation, Python, browser, or internet required.

START
Extract this ZIP, then double-click Folderly.exe. The source folder is optional.

1. Choose folder (or drag a folder onto the app).
2. Review the file list and destination-folder preview.
3. Click a green destination name, or double-click a row, to edit the folder.
   Enter saves your edit; Escape cancels the edit.
4. Select or deselect files with their checkboxes. All / None affect the filtered list.
5. Click Organize and confirm the folder and file count.

WHAT IT DOES
- Scans loose files in the chosen folder; leaves existing subfolders alone.
- Suggests names from actual filenames. It does not query online databases.
- Optionally retains release years and cleans resolution/codec/release tags.
- Groups matching subtitles, artwork, and metadata with their video.
- Renames files into folders in the same drive. No full movie copying.
- Preserves every original filename.
- Handles Unicode filenames and uses extended-length Windows paths.
- Skips existing destinations, invalid folder names, changed source files,
  and linked/reparse-point destination folders. It never overwrites files.
- Runs scanning and moving in the background with progress and cancellation.
- Shows skipped-file reasons after moving. Click a file with a red warning
  in the preview to see its conflict description.

UNDO
Undo last batch restores successfully moved files from the latest batch in
this app session. It skips files modified after moving and occupied original
paths. Close the app and the session undo history is lost. A new successful
batch replaces the previous undo history. Created folders remain after undo.
If there are skipped restores, the remaining undo records stay available.

SHORTCUTS
Ctrl+O: choose folder. Ctrl+Z: undo. Ctrl+A: select all files.
F5: rescan. Escape while busy: request cancellation after the current file.

NAMING
Filename cleanup is a suggestion; check the preview before applying it.
For plain filenames, disable "Clean resolution & release tags" to use the
exact filename stem as the folder name. Changing either naming option
regenerates the current suggestions after confirmation.

BUILD AND VALIDATION
This executable was cross-compiled for Windows x64 with MinGW-w64.
The core naming and organizing algorithm passed 27 checks using a host
filesystem adapter: moves, undo, existing destinations, stale sources,
Unicode names, numeric movie titles, invalid paths, and linked folders.
10,000 naming suggestions took about 0.12 seconds on the build host.
The native drawing layout was also inspected with a host rendering adapter.
The actual Windows GUI/runtime could not be launched in the build environment;
it has not had a full native Windows acceptance test.
The executable imports only Windows system DLLs; the C++ runtime is static.

The C++ source, resource, and application manifest are included under source/.
